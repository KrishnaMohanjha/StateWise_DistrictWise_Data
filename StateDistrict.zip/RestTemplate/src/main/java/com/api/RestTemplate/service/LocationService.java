	package com.api.RestTemplate.service;
	
	import org.json.JSONArray;
	import org.json.JSONObject;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.stereotype.Service;
	import org.springframework.web.client.RestTemplate;
	
	import java.util.logging.Logger;
	
	@Service
	public class LocationService {

	    @Autowired
	    private final RestTemplate restTemplate = new RestTemplate();

	    private static final Logger logger = Logger.getLogger(LocationService.class.getName());

	    public String getAllDistrictsAndStates() {
	        String url = "http://api.nightlights.io/districts";
	        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

	        // Log the entire response for debugging
	        logger.info("API Response: " + response.getBody());

	        return response.getBody();
	    }

	    public String getDistrictsByStateAndDistrict(String stateName, String districtName) {
	        String responseBody = getAllDistrictsAndStates();
	        JSONObject jsonObject = new JSONObject(responseBody);
	        JSONArray regions = jsonObject.getJSONArray("regions");

	        logger.info("Total regions found: " + regions.length());

	        JSONArray filteredDistricts = new JSONArray();

	        // Normalize input for comparison
	        String normalizedStateName = stateName != null ? stateName.trim().toLowerCase() : "";
	        String normalizedDistrictName = districtName != null ? districtName.trim().toLowerCase() : "";

	        for (int i = 0; i < regions.length(); i++) {
	            JSONObject region = regions.getJSONObject(i);

	            // Normalize API data for comparison
	            String apiStateName = region.optString("state_name", "").trim().toLowerCase();
	            String apiDistrictName = region.optString("district_name", "").trim().toLowerCase();

	            logger.info("Checking region - State: " + apiStateName + ", District: " + apiDistrictName);

	            boolean stateMatch = normalizedStateName.equals(apiStateName);
	            boolean districtMatch = normalizedDistrictName.isEmpty() || normalizedDistrictName.equals(apiDistrictName);
	            logger.info("State Match: " + stateMatch + ", District Match: " + districtMatch);

	            if (stateMatch && districtMatch) {
	                logger.info("Match found: " + region.toString());
	                filteredDistricts.put(region);
	            }
	        }

	        logger.info("Filtered regions count: " + filteredDistricts.length());

	        JSONObject result = new JSONObject();
	        result.put("regions", filteredDistricts);
	        return result.toString();
	    }
	}
